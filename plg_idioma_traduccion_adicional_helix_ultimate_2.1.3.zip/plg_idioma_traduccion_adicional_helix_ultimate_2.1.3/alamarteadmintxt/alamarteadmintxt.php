<?php
defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Document\HtmlDocument;

class PlgSystemAlamarteadmintxt extends CMSPlugin
{
    protected $app;

    public function onAfterDispatch()
    {
        if (!$this->app->isClient('administrator')) return;
        $doc = $this->app->getDocument();
        if (!$doc instanceof HtmlDocument) return;

        $js = <<<JS
(function(){
  'use strict';
  window.__alamarteAdmTxt = '1.2.0';

  const LONG_EN = 'Helix Ultimate - Starter Template of Helix Ultimate Framework';
  const LONG_ES = 'Helix Ultimate – Plantilla base del framework Helix Ultimate.';

  const MAP = new Map(Object.entries({
    // Botones comunes
    'apply':'Aplicar',
    'reset to default':'Restablecer',
    'save':'Guardar',
    'cancel':'Cancelar',
    'template options':'Opciones de la plantilla',

    // Presets labels
    'topbar text color':'Color de texto de la barra superior',
    'header background color':'Color de fondo de la cabecera',
    'logo text color':'Color del texto del logo',
    'menu text color':'Color del texto del menú',
    'menu text hover color':'Color del texto al pasar el ratón',
    'menu text active color':'Color del texto activo',
    'menu dropdown background color':'Color de fondo del desplegable',
    'menu dropdown text color':'Color del texto del desplegable',
    'menu dropdown text hover color':'Color del texto del desplegable al pasar el ratón',
    'menu dropdown text active color':'Color del texto activo del desplegable',
    'body text color':'Color del texto del cuerpo',
    'body background color':'Color de fondo del cuerpo',
    'body link color':'Color de enlace del cuerpo',
    'body link hover color':'Color del enlace del cuerpo al pasar el ratón',
    'footer background color':'Color de fondo del pie',
    'footer text color':'Color del texto del pie',
    'footer link color':'Color de enlace del pie',
    'footer link hover color':'Color del enlace del pie al pasar el ratón',

    // Layout (pedido)
    'component':'Componente',
    'select an option':'Seleccionar posición',
    'none':'Ninguno',
    'layout':'Diseño'
  }));

  function norm(s){ return (s||'').replace(/\s+/g,' ').trim().toLowerCase(); }
  function normNoIcons(el){
    const c = el.cloneNode(true);
    c.querySelectorAll('i,svg').forEach(n=>n.remove());
    return norm(c.textContent);
  }

  function translateBasic(root){
    const sel = [
      'button','a','[role="button"]','.btn','span','label','.control-label',
      'h1','h2','h3','h4','h5','h6','p','.card-title','.page-title','.hu-column-title'
    ].join(',');
    root.querySelectorAll(sel).forEach(el=>{
      const n = normNoIcons(el);
      if(MAP.has(n)) el.textContent = MAP.get(n);
      ['title','aria-label','value','placeholder','data-original-title','data-bs-original-title'].forEach(a=>{
        const v = el.getAttribute && el.getAttribute(a);
        if(!v) return;
        const nv = norm(v);
        if(MAP.has(nv)) el.setAttribute(a, MAP.get(nv));
      });
    });
  }

  function translateLongPhrase(root){
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    let node; const targets = [];
    while(node = walker.nextNode()){
      const t = node.nodeValue.replace(/\s+/g,' ').trim();
      if(t === LONG_EN) targets.push(node);
    }
    targets.forEach(n => n.nodeValue = LONG_ES);
  }

  // Títulos de presets
  function translatePresetTitles(root){
    root.querySelectorAll('.hu-preset-title').forEach(el=>{
      const txt = (el.textContent||'').trim();
      const m = /^Preset\s+(\d+)$/i.exec(txt);
      if(m){ el.textContent = 'Preajuste ' + m[1]; }
    });
    root.querySelectorAll('.hu-preset[data-preset]').forEach(card=>{
      const title = card.querySelector('.hu-preset-title');
      if(!title) return;
      if(/^\s*$/.test(title.textContent||'')){
        const n = String(card.getAttribute('data-preset')||'').replace(/^[^0-9]*/,''); 
        if(n) title.textContent = 'Preajuste ' + n;
      }
    });
  }

  // Botón Guardar con spinner
  function fixHuSave(root){
    root.querySelectorAll('button.hu-save-btn').forEach(btn => {
      const nodes = Array.from(btn.childNodes).filter(n => n.nodeType === Node.TEXT_NODE);
      if (nodes.length){
        const last = nodes[nodes.length - 1];
        if (/save\s*$/i.test(last.nodeValue||'')){
          last.nodeValue = ( /^\s+/.test(last.nodeValue||'') ? ' ' : '' ) + 'Guardar';
        }
      }else{
        const t = (btn.textContent||'').replace(/\s+/g,' ').trim().toLowerCase();
        if(t === 'save') btn.appendChild(document.createTextNode(' Guardar'));
      }
      if ((btn.getAttribute('title')||'').toLowerCase()==='save') btn.setAttribute('title','Guardar');
      if ((btn.getAttribute('aria-label')||'').toLowerCase()==='save') btn.setAttribute('aria-label','Guardar');
    });
  }

  function process(root){
    translateBasic(root);
    translateLongPhrase(root);
    translatePresetTitles(root);
    fixHuSave(root);
  }

  document.addEventListener('DOMContentLoaded', ()=>{
    process(document);
    const scan = () => document.querySelectorAll('iframe').forEach(f=>{
      try{
        const d = f.contentDocument || f.contentWindow?.document;
        if(d){
          process(d);
          new MutationObserver(ms=>ms.forEach(m=>m.addedNodes && m.addedNodes.forEach(n=>{ if(n instanceof HTMLElement) process(n); })))
            .observe(d.documentElement,{childList:true,subtree:true});
        }
      }catch(e){}
    });
    scan();
    let i=0; const id=setInterval(()=>{ process(document); scan(); if(++i>30) clearInterval(id); },150);
  });

  new MutationObserver(ms=>ms.forEach(m=>m.addedNodes && m.addedNodes.forEach(n=>{
    if(!(n instanceof HTMLElement)) return;
    process(n);
  }))).observe(document.documentElement,{childList:true,subtree:true});
})();
JS;
        $doc->addScriptDeclaration($js);
    }
}
